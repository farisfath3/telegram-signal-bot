import os
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes
from datetime import datetime

TOKEN = os.getenv("TOKEN")
ALPHA_KEY = os.getenv("ALPHA_KEY")
GOLDAPI_KEY = os.getenv("GOLDAPI_KEY")
TWELVE_KEY = os.getenv("TWELVE_KEY")

CHAT_ID = "7139384885"

# Pair list (Forex + Crypto + Gold)
pairs = [
    "EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "USDCAD", "GBPJPY",
    "EURJPY", "NZDUSD", "XAUUSD", "BTCUSD", "ETHUSD", "BNBUSD", "XRPUSD",
    "SOLUSD"
]


# === Fetch live price ===
def get_live_price(pair):
    try:
        if pair == "XAUUSD":
            headers = {
                "x-access-token": GOLDAPI_KEY,
                "Content-Type": "application/json"
            }
            r = requests.get("https://www.goldapi.io/api/XAU/USD",
                             headers=headers)
            data = r.json()
            return float(data["price"])

        elif pair in ["BTCUSD", "ETHUSD", "BNBUSD", "XRPUSD", "SOLUSD"]:
            coingecko_ids = {
                "BTCUSD": "bitcoin",
                "ETHUSD": "ethereum",
                "BNBUSD": "binancecoin",
                "XRPUSD": "ripple",
                "SOLUSD": "solana"
            }
            coin_id = coingecko_ids.get(pair)
            r = requests.get(
                f"https://api.coingecko.com/api/v3/simple/price?ids={coin_id}&vs_currencies=usd"
            )
            return float(r.json()[coin_id]["usd"])

        else:
            symbol = pair[:3] + "/" + pair[3:]
            url = f"https://api.twelvedata.com/price?symbol={symbol}&apikey={TWELVE_KEY}"
            r = requests.get(url)
            data = r.json()
            if "price" not in data:
                print(f"TwelveData response: {data}")
                return None
            return float(data["price"])

    except Exception as e:
        print(f"Error fetching price for {pair}: {e}")
        return None


# === Generate Signal ===
def generate_signal(pair, price):
    trend = "BUY" if datetime.now().second % 2 == 0 else "SELL"

    if trend == "BUY":
        tp1 = price * 1.004
        tp2 = price * 1.006
        tp3 = price * 1.008
        sl = price * 0.995
    else:
        tp1 = price * 0.996
        tp2 = price * 0.994
        tp3 = price * 0.992
        sl = price * 1.005

    return trend, tp1, tp2, tp3, sl


# === Send Signal ===
async def send_signal(update: Update, context: ContextTypes.DEFAULT_TYPE,
                      pair: str):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        f"Getting signal for: {pair}...")

    price = get_live_price(pair)
    if price is None:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=f"⚠️ Failed to fetch live price for {pair}.")
        return

    trend, tp1, tp2, tp3, sl = generate_signal(pair, price)

    symbol = "🟢" if trend == "BUY" else "🔴"
    msg = f"{symbol} Auto {trend} Signal for {pair}\nEntry: {price:.3f}\nTP1: {tp1:.3f}\nTP2: {tp2:.3f}\nTP3: {tp3:.3f}\nSL: {sl:.3f}"
    await context.bot.send_message(chat_id=update.effective_chat.id, text=msg)


# === Telegram Bot ===
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    buttons = [[
        InlineKeyboardButton("BTCUSD", callback_data="BTCUSD"),
        InlineKeyboardButton("ETHUSD", callback_data="ETHUSD")
    ],
               [
                   InlineKeyboardButton("XAUUSD", callback_data="XAUUSD"),
                   InlineKeyboardButton("EURUSD", callback_data="EURUSD")
               ],
               [
                   InlineKeyboardButton("USDJPY", callback_data="USDJPY"),
                   InlineKeyboardButton("GBPUSD", callback_data="GBPUSD")
               ],
               [
                   InlineKeyboardButton("SOLUSD", callback_data="SOLUSD"),
                   InlineKeyboardButton("BNBUSD", callback_data="BNBUSD")
               ]]
    reply_markup = InlineKeyboardMarkup(buttons)
    await update.message.reply_text("Choose a Forex/Crypto Pair:",
                                    reply_markup=reply_markup)


async def handle_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pair = update.callback_query.data
    await send_signal(update, context, pair)


if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(handle_button))
    print("✅ Bot is running...")
    app.run_polling()
