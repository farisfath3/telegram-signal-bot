# ✅ cron.py - auto-send signal ke Telegram setiap run
import os
import requests
import asyncio
import time
from telegram import Bot

# Init
TOKEN = os.getenv("TOKEN")
ALPHA_KEY = os.getenv("ALPHA_KEY")
GOLDAPI_KEY = os.getenv("GOLDAPI_KEY")
CHAT_ID = "7139384885"

bot = Bot(token=TOKEN)

# Pair list (limited for testing)
pairs = ["EURUSD", "GBPUSD", "USDJPY", "XAUUSD"]


# === Fetch price ===
def get_live_price(pair):
    if pair == "XAUUSD":
        try:
            headers = {
                "x-access-token": GOLDAPI_KEY,
                "Content-Type": "application/json"
            }
            r = requests.get("https://www.goldapi.io/api/XAU/USD",
                             headers=headers).json()
            return float(r["price"])
        except:
            return None

    elif pair in ["BTCUSD", "ETHUSD", "BNBUSD", "XRPUSD", "SOLUSD"]:
        try:
            url = f"https://www.alphavantage.co/query?function=DIGITAL_CURRENCY_DAILY&symbol={pair[:3]}&market=USD&apikey={ALPHA_KEY}"
            r = requests.get(url).json()
            ts = r.get("Time Series (Digital Currency Daily)", {})
            if not ts: return None
            latest = sorted(ts.keys())[-1]
            return float(ts[latest]["4a. close (USD)"])
        except:
            return None

    else:
        try:
            url = f"https://www.alphavantage.co/query?function=FX_DAILY&from_symbol={pair[:3]}&to_symbol={pair[3:]}&apikey={ALPHA_KEY}"
            r = requests.get(url).json()
            ts = r.get("Time Series FX (Daily)", {})
            if not ts: return None
            latest = sorted(ts.keys())[-1]
            return float(ts[latest]["4. close"])
        except:
            return None


# === Send all signals ===
async def send_signals():
    for pair in pairs:
        price = get_live_price(pair)
        if price:
            tp = price * 1.01
            sl = price * 0.99
            msg = f"Auto Signal for {pair}\nEntry: {price:.3f}\nTP: {tp:.3f}\nSL: {sl:.3f}"
        else:
            msg = f"Failed to fetch live price for {pair}"

        try:
            await bot.send_message(chat_id=CHAT_ID, text=msg)
        except Exception as e:
            print(f"Failed to send message for {pair}: {e}")

        time.sleep(5)  # Wait 5 seconds between requests to avoid rate limits


# Run the async function
asyncio.run(send_signals())
